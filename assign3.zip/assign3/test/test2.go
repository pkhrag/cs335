package main;

import (
	"fmt";
	"time";
);

func f(a int_t, b int_t)
{
	fmt.Println("Hello");
};

func main() {
	fmt.Println("Welcome to the playground!");
	var b int_t = 4;
	var a int_t=5;
	f(b, a);
};
