cd bin
python parser.py ../$1
mv  *.html ../