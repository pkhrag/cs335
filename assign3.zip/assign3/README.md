Instructions to run the code generator
------------------------------

* Go to the folder 'assign3'
* Type `make`
* Type `./bin/parser ./test/testfile.go`. Replace `testfile` with any of the file present in test folder.
* type `firefox testfile.html`
* Type `make clean` after successfully testing the parser.

