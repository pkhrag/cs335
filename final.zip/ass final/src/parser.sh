cd bin
python parser.py ../$1
