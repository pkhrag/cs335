package main;

import (
	"fmt";
);

func mergesort(numbers *int_t, n int_t,) {
	if n == 1 {
		return ;
	};

	var l,r int_t;
	l = n/2;
	r = n-left;

	var left
};
