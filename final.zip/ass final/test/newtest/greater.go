package operation;

import (
	"fmt";
);

func main() {
	var a,b int_t;
	scan a;
	scan b;
	if a<b {
		print %d 1;
	}
	else {
		print %d 2;
	};
	return;
};
