package mai;

import "fmt";

func main() {
	var i,j int_t;
	scan i;
	scan j;
	print %d i;
	print %d j;
};
