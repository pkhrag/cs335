package math0;
import "fmt";
import "heya";
import (
    "fmttt";
    "heyaaa";
);

const t int_t = 3;
var i int_t = 5;
var (
    l = t*i ;
);

func main() {
    i += 3;
	lsls :
    if i>3 {
        i+=7;
    }
    else{
        i-=7;
    };
	for i := 1; i < 3; i++{
		var j int_t = 3;
		if j < 2 {
			break lsls;
		};
	};
	dsds :
	print i;
	print t;
	print l;
	return;    
};
