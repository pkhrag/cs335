package math;
import "fmt";


func foo(a int_t) int_t
{
	var k int_t = 3;
	print k;
	return k;
};

func main() {

	var a int_t = 1;
	foo(a);
	return;
};
