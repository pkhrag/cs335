package math;
import "fmt";

func main() {

	var i int_t = 4;
	if i>4{
        i+=7;
    }
    else{
        i-=7;
    };
	print i;
	return;
};
