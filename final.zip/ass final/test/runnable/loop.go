package math;
import "fmt";

var bar int_t = 3;

func foo() int_t {
	return bar;
};

func main() {

	var a int_t = foo();
	return;
};
