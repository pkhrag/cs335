package math;
import "fmt";

type Vertex struct{
	i int_t;
	j int_t;
};

func main() {
	
	var a[33] int_t;
	a[3] = 3;
	var d,e type Vertex;
	var i int_t = 2;
	d.i = 3;
	e.i = 1;
	print d.i;
	print  -e.i;
	print  +i;
};
