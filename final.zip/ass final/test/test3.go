package maie;

import "fmt";
func test(a, b int_t) float_t;


func main() {
	var i int_t =3;
	var j int_t = test(1,2);
	i  += j;
	print i;
};

func test(a, b int_t) int_t {
	return a;
};

