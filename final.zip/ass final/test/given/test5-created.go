package math;
import "fmt";

func main()
{
	var c,d,e int_t = 16,0,0;
	if c||d{
		d++;
	}
	else{
		if d&e{
			e++;
		}
		else{
			d--;
		};
	};

	print c;
	print d;
};
