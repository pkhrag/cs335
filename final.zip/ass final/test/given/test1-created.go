package math;
import "fmt";

func main() {

	var a,b,c,d,e int_t =1,2,3,4,5;
	a = b+c-d/e*b%10;
	print a;
	return;
};
