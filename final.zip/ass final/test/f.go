package mai;
import "fmt";
func main() {
	
	var h [3] int_t;
	h[2] = 1;
	var t *int_t;
	t = &h[0];
	print %d *(t+2);
	return;
};
