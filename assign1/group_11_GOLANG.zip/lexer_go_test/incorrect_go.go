package main

import "fmt"

func main() {
	var i int = 6
	for ; i <=8 && i 6.67 && i!=7; i++ {
		var 36a int
		var `$#@name int
			if i>=0; {
				fmt.Println("yes")
			} else {
				fmt.Println("no")
			}
		
	}
}