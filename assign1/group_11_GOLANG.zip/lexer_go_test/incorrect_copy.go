package main

import "fmt"

func main() {
	var i int=6
	for i := 0; i <= 8 && i < 6.67 && i!=7; i++ {

		var  0x123
		var 1e2, 1e2e3,1.2.3
		if i>=0 {
			fmt.Println("yes")
		} else {
			fmt.Println("no")
		}
		
	}
}