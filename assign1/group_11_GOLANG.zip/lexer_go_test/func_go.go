package main

func foo() {
	var i int = 1 
}

func main() {
	foo()
}