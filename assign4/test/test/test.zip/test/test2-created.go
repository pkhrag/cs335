package math;
import "fmt";

func main() {

	var c,d int_t = 1,0;
	if c{
		if d{
			d++;
		}
		else{
			d--;
		};
	};

	print d;
	return;
};
