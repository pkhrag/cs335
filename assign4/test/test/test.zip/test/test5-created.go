package math;
import "fmt";

func main()
{
	var c,d,e int_t = 1,0,1;
	if c&&d{
		d++;
	}
	else{
		if d&e{
			e++;
		}
		else{
			d--;
		};
	};

	print c;
	print d;
};