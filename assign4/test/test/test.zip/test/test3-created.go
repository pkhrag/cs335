package math;
import "fmt";

func main() {

	var a int_t = 0;
	for i:=0;i <100; i++{
		a++;
	};
	print a;
	return;
};
